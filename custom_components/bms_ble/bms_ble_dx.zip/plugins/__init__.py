"""Package for battery management systems (BMS) plugins."""
